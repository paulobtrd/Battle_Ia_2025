Pour générer la dll :
dotnet build
