﻿namespace BattleIA
{
    public class MapXY
    {
        public byte X;
        public byte Y;
    }
}